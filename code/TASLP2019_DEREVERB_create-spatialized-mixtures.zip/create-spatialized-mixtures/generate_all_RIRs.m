%Copyright [2020] [Zhong-Qiu Wang] (The Ohio State University)

%Licensed under the Apache License, Version 2.0 (the "License");
%you may not use this file except in compliance with the License.
%You may obtain a copy of the License at

%http://www.apache.org/licenses/LICENSE-2.0

%Unless required by applicable law or agreed to in writing, software %distributed under the License is distributed on an "AS IS" BASIS, %WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%See the License for the specific language governing permissions and
%limitations under the License.

function generate_all_RIRs(),

    fs = 16000;

    if fs == 16000,
        rir_dir = '/scratch_pnl18/wangzhon/dereverb_signals/RIRs_16k/';
        fs_str = '16k';
    elseif fs == 8000,
        rir_dir = '/scratch_pnl18/wangzhon/dereverb_signals/RIRs_8k/';
        fs_str = '8k';
    end

    if ~isdir(rir_dir),
        mkdir(rir_dir);
    end

    MAX_NUM_RIRS = 48000; %generate slightly more
    generate_RIRs(rir_dir, MAX_NUM_RIRS, fs);

    system(['find ',rir_dir,' -name "*.mat" | sort -u > RIRs_',fs_str,'.flist']);
    flist_rir = importdata(['RIRs_',fs_str,'.flist']);

end

function generate_RIRs(rir_dir, MAX_NUM_RIRS, fs),

    addpath('~/QuantizedMasks/chime2qm/tools/RIR-Generator/');

    fprintf('generate_RIRs(rir_dir, MAX_NUM_RIRS, fs);');

    mtype           = 'omnidirectional';%Type of microphone
    order           = -1;               %-1 equals maximum reflection order!
    dim             = 3;                %Room dimension
    sound_speed     = 340;              %Sound velocity (m/s)
    hp_filter       = 1;                %Enable high-pass filter
    orientation     = [0, 0];           %Microphone orientation (rad), doesn't matter for omnidirectional microphones

    room_l_range    = [5, 10]; %(m)
    room_w_range    = [5, 10]; %(m)
    room_h_range    = [3, 4];  %(m)

    array_z_range       = [1, 2]; %(m), array height
    array_radius_range  = [0.03, 0.1]; %(m), array spacing, for circular array
    array_xy_jittering  = 0.5; %(m), reduce the difficulty, first get something work

    T60_range   = [0.2, 1.3]; %(s), for 16k

    M           = 8; %number of microphones
    S           = 4; %number of sources

    c = parcluster('local');
    c.NumWorkers = 16;
    parpool(c, c.NumWorkers);

    MAX_NUM_TRIAL = 1000;

    parfor kk = 1 : 48000,

        fprintf('processing %d/%d, ', kk, MAX_NUM_RIRS);

        seed = kk*7;

        rng(seed,'twister');

        room_l = draw(room_l_range);
        room_w = draw(room_w_range);
        room_h = draw(room_h_range);

        room_dimension = [room_l, room_w, room_h]; %Room dimensions

        array_x = room_l/2 + (rand*2-1)*array_xy_jittering; %the array_x would be +-array_xy_jittering near the center
        array_y = room_w/2 + (rand*2-1)*array_xy_jittering; %the array_y would be +-array_xy_jittering near the center
        array_z = draw(array_z_range);
        array_center = [array_x, array_y, array_z];

        array_radius = draw(array_radius_range);
        degree_step = 360/M;
        first_mic_degree = draw([0,degree_step])
        mic_pos = [];
        for mm = 1 : M,
            mic_angle = (first_mic_degree+(mm-1)*degree_step) / 180*pi
            mic_pos = [mic_pos; array_radius*cos(mic_angle),array_radius*sin(mic_angle),0];
        end
        mic_pos = bsxfun(@plus, mic_pos, array_center);

        spk_dist_range = [0.75, 2.5];

        success = false;
        num_trials = 0;
        while success == false && num_trials < MAX_NUM_TRIAL,
            spk_pos = [];
            all_spk_angl = [];
            all_spk_dist = [];
            for ss = 1 : S,
                spk_dist = draw(spk_dist_range);
                spk_angl = draw([0,360]);
                all_spk_angl = [all_spk_angl; spk_angl];
                all_spk_dist = [all_spk_dist; spk_dist];
                spk_angl = spk_angl/180*pi;
                spk_pos = [spk_pos; cos(spk_angl)*spk_dist+array_center(1), sin(spk_angl)*spk_dist+array_center(2), array_center(3)];
            end
            success = check_spks_angl_pos(all_spk_angl, spk_pos, room_dimension);
            if success == false,
                fprintf('.');
                for ss = 1 : S,
                    fprintf('%.1f ',all_spk_angl(ss));
                end
                num_trials = num_trials + 1;
            end
        end
        if num_trials == MAX_NUM_TRIAL,
            fprintf('maximum number of trials reached on kk=%d. skiping\n', kk);
            continue;
        end

        % for reverb
        T60 = draw(T60_range);  %Reverberation time (s)
        filter_len = fs*(T60+0.1);
        fprintf('T60=%f\n', T60);
        h_reverb_1 = rir_generator(sound_speed, fs, mic_pos, spk_pos(1,:), room_dimension, T60, filter_len, mtype, order, dim, orientation, hp_filter);
        h_reverb_2 = rir_generator(sound_speed, fs, mic_pos, spk_pos(2,:), room_dimension, T60, filter_len, mtype, order, dim, orientation, hp_filter);
        h_reverb_3 = rir_generator(sound_speed, fs, mic_pos, spk_pos(3,:), room_dimension, T60, filter_len, mtype, order, dim, orientation, hp_filter);
        h_reverb_4 = rir_generator(sound_speed, fs, mic_pos, spk_pos(4,:), room_dimension, T60, filter_len, mtype, order, dim, orientation, hp_filter);

        % for anechoic
        filter_len = fs*0.1;
        h_anechoic_1 = rir_generator(sound_speed, fs, mic_pos, spk_pos(1,:), room_dimension, 0.0, filter_len, mtype, order, dim, orientation, hp_filter);
        h_anechoic_2 = rir_generator(sound_speed, fs, mic_pos, spk_pos(2,:), room_dimension, 0.0, filter_len, mtype, order, dim, orientation, hp_filter);
        h_anechoic_3 = rir_generator(sound_speed, fs, mic_pos, spk_pos(3,:), room_dimension, 0.0, filter_len, mtype, order, dim, orientation, hp_filter);
        h_anechoic_4 = rir_generator(sound_speed, fs, mic_pos, spk_pos(4,:), room_dimension, 0.0, filter_len, mtype, order, dim, orientation, hp_filter);

        save_rir(rir_dir, kk, h_reverb_1, h_reverb_2, h_reverb_3, h_reverb_4, h_anechoic_1, h_anechoic_2, h_anechoic_3, h_anechoic_4, fs, mic_pos, spk_pos, all_spk_angl, all_spk_dist, array_radius, room_dimension, T60, mtype, order, dim, orientation, hp_filter, first_mic_degree);

    end

    delete(gcp);

end

function save_rir(rir_dir, kk, h_reverb_1, h_reverb_2, h_reverb_3, h_reverb_4, h_anechoic_1, h_anechoic_2, h_anechoic_3, h_anechoic_4, fs, mic_pos, spk_pos, all_spk_angl, all_spk_dist, array_radius, room_dimension, T60, mtype, order, dim, orientation, hp_filter, first_mic_degree),
    save([rir_dir,'/rir_',sprintf('%05d',kk),'.mat'], 'h_reverb_1', 'h_reverb_2', 'h_reverb_3', 'h_reverb_4', 'h_anechoic_1', 'h_anechoic_2', 'h_anechoic_3', 'h_anechoic_4', 'fs', 'mic_pos', 'spk_pos', 'all_spk_angl', 'all_spk_dist', 'array_radius', 'room_dimension', 'T60', 'mtype', 'order', 'dim', 'orientation', 'hp_filter', 'first_mic_degree');
end

function [success] = check_spks_angl_pos(all_spk_angl, spk_pos, room_dimension),
    success = false;
    for i = 1 : size(all_spk_angl,1),
        for j = i + 1 : size(all_spk_angl,1),
            if abs(all_spk_angl(i)-all_spk_angl(j)) < 15,
                return;
            end
        end
    end
    for i = 1 : size(spk_pos,1),
        if (spk_pos(i,1)<0.5) || (spk_pos(i,1)>room_dimension(1)-0.5),
            return;
        end
        if (spk_pos(i,2)<0.5) || (spk_pos(i,2)>room_dimension(2)-0.5),
            return;
        end
    end
    success = true;
end

function num = draw(range),
    if range(1) > range(2),
        error('error\n');
    end
    num = (range(2)-range(1))*rand+range(1);
end
