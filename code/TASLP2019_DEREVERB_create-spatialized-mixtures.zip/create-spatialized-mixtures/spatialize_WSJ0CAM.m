%Copyright [2020] [Zhong-Qiu Wang] (The Ohio State University)

%Licensed under the Apache License, Version 2.0 (the "License");
%you may not use this file except in compliance with the License.
%You may obtain a copy of the License at

%http://www.apache.org/licenses/LICENSE-2.0

%Unless required by applicable law or agreed to in writing, software %distributed under the License is distributed on an "AS IS" BASIS, %WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%See the License for the specific language governing permissions and
%limitations under the License.

function spatialize_WSJ0CAM(),

    fs = 16000;

    if fs == 16000,
        rir_dir = '/scratch_pnl18/wangzhon/dereverb_signals/RIRs_16k/';
        fs_str = '16k';
    elseif fs == 8000,
        rir_dir = '/scratch_pnl18/wangzhon/dereverb_signals/RIRs_8k/';
        fs_str = '8k';
    end

    if ~isdir(rir_dir),
        mkdir(rir_dir);
    end

    NUM_UTT_IN_WSJ0CAM = [7861,742,1088];
    DUPLICATE = [5,4,3]; %45537=7861*5+742*4+1088*3

    system(['find ',rir_dir,' -name "*.mat" | sort -u > RIRs_',fs_str,'.flist']);
    flist_rir = importdata(['RIRs_',fs_str,'.flist']);

    flist_rir = flist_rir(1:min(length(flist_rir), NUM_UTT_IN_WSJ0CAM*DUPLICATE'));

    spatialize_speech(flist_rir, fs, fs_str, NUM_UTT_IN_WSJ0CAM, DUPLICATE);
end

function ret = load_REVERB_noise(fs),
    REVERB_data_root = '/scratch_pnl18/wangzhon/reverb_challenge/REVERB_DATA_OFFICIAL/';
    subsets_names = {'reverb_tools_for_Generate_mcTrainData','reverb_tools_for_Generate_SimData'};
    ret = struct;
    for i = 1:numel(subsets_names),
        sources_folder = fullfile(REVERB_data_root,subsets_names{i},'/NOISE/');
        sources_dir = dir(sources_folder);
        n = numel(sources_dir)-2;
        for j = 1:n,
            [noise, old_fs] = audioread([sources_folder,'/',sources_dir(j+2).name]);
            if old_fs ~= fs,
                error('');
            end
            ret(i).wavs(j).sig  = noise; %eight channel
            fprintf('.');
        end
        fprintf('|');
    end
end

function spatialize_speech(flist_rir, fs, fs_str, NUM_UTT_IN_WSJ0CAM, DUPLICATE),

    data_root_wsj0cam = '/scratch_pnl18/wangzhon/reverb_challenge/kaldi_s5_related/wav/WSJCAM0/data/';
    data_root_to_save = ['/scratch_pnl18/wangzhon/dereverb_signals/wsj0cam_sph_',fs_str];

    datasets = {'primary_microphone/si_tr','primary_microphone/si_dt','*_microphone/si_et_*'};
    datasets_to_save = {'train','validation','test'};

    fprintf('loading REVERB NOISE');
    NOISE = load_REVERB_noise(fs);
    fprintf('done\n');

    c = parcluster('local');
    c.NumWorkers = 16;
    parpool(c, c.NumWorkers);

    for dd = 1 : length(datasets),

        if strcmp(datasets_to_save{dd},'train') == 1,
            rir_counter = 0;
            duplicate   = DUPLICATE(1);
            datasets_idx= 1;
        elseif strcmp(datasets_to_save{dd},'validation') == 1,
            rir_counter = NUM_UTT_IN_WSJ0CAM(1)*DUPLICATE(1);
            duplicate   = DUPLICATE(2);
            datasets_idx= 1;
        elseif strcmp(datasets_to_save{dd},'test') == 1,
            rir_counter = NUM_UTT_IN_WSJ0CAM(1)*DUPLICATE(1)+NUM_UTT_IN_WSJ0CAM(2)*DUPLICATE(2);
            duplicate   = DUPLICATE(3);
            datasets_idx= 2;
        else
            error('');
        end

        system(['find ',data_root_wsj0cam,'/',datasets{dd},'/ -name "*.wav" | sort -u > wsj0cam_',datasets_to_save{dd},'_sph.flist']);
        flist_sph = importdata(['wsj0cam_',datasets_to_save{dd},'_sph.flist']);
        length(flist_sph)

        %
        %duplicate flist_sph
        %repeat each utterance for multiple times
        %
        tmp_flist = {};
        for tmptmp = 1 : duplicate,
            tmp_flist = {tmp_flist{:},flist_sph{:}};
        end
        flist_sph = tmp_flist;
        length(flist_sph)

        parfor fInd = 1 : length(flist_sph),

            seed = (rir_counter+fInd)*7;
            rng(seed,'twister');

            filename = get_filename(flist_sph{fInd});

            %
            %load RIR
            %
            info_ = load(flist_rir{rir_counter+fInd});

            %
            %load WSJ0CAM utterances
            %
            [sph, fs_wsj0cam]= audioread(flist_sph{fInd});
            if fs_wsj0cam ~= fs,
                error('');
            end
            sph = sph - mean(sph);

            %
            %load noise
            %
            noi_idx = randi(length(NOISE(datasets_idx).wavs));
            sampl_idx = randi(length(NOISE(datasets_idx).wavs(noi_idx).sig)-length(sph)+1);
            noi = NOISE(datasets_idx).wavs(noi_idx).sig(sampl_idx:sampl_idx+length(sph)-1,:);
            snr_range = [5,25];
            reverb_snr_ane_noi = draw(snr_range);
 
            fprintf('using RIR %s, spatializing %s...', flist_rir{rir_counter+fInd}, flist_sph{fInd});
            fprintf('T60=%f...', info_.T60);
            fprintf('reverb_snr_ane_noi=%.3f...', reverb_snr_ane_noi);

            anechoic_sph = synthesis_reverberation(info_.h_anechoic_1', sph);
            reverb_sph = synthesis_reverberation(info_.h_reverb_1', sph);

            scaling_factor = scale_to_snr(anechoic_sph, noi, reverb_snr_ane_noi);
            noi = noi * scaling_factor;

            reverb_sph = reverb_sph + noi;

            [anechoic_sph, reverb_sph, scaling_factor] = scale_to_max_sample_value(anechoic_sph, reverb_sph, 0.95);

            filename = [filename(1:end-4),...
                       '_',num2str(info_.array_radius*100,'%.2f'),...
                       '_',num2str(info_.first_mic_degree,'%.1f'),...
                       '_',num2str(info_.T60,'%.2f'),...
                       '_',num2str(info_.all_spk_dist(1),'%.2f'),'_',num2str(info_.all_spk_angl(1),'%.1f'),...
                       '_',num2str(reverb_snr_ane_noi),'.wav'];

            if std(reverb_sph(:)) == 0 || std(anechoic_sph(:)) == 0,
                error('');
            end

            anechoic_sph_dir = [data_root_to_save,'/',datasets_to_save{dd},'/anechoic_sph/'];
            system(['mkdir -p ', anechoic_sph_dir]);
            save_wav([anechoic_sph_dir,filename], anechoic_sph, fs);

            reverb_sph_dir  = [data_root_to_save,'/',datasets_to_save{dd},'/reverb_sph/'];
            system(['mkdir -p ', reverb_sph_dir]);
            save_wav([reverb_sph_dir,filename], reverb_sph, fs);

            fprintf('done\n');
        end
    end
    delete(gcp);
end

function h_firstpeak = get_firstpeak_rir(h_anechoic),
    h_firstpeak = zeros(size(h_anechoic));    
    [val, idx] = max(h_anechoic, [], 2);
    for ii=1:size(val,1),
        h_firstpeak(ii, idx(ii)) = val(ii);
    end
end

function scaling_factor = scale_to_snr(sph, noi, snr_sph_noi),
    scaling_factor  = sqrt((1.0/10^(snr_sph_noi/10))*sum(sph(:).^2)/sum(noi(:).^2));
end

function save_wav(filepath, signal, fs),
    audiowrite(filepath, signal, fs);
end

function d = dist(a, b),
    d = sqrt(sum((a-b).^2));
end

function [anechoic_sph,reverb_sph,scaling_factor] = scale_to_max_sample_value(anechoic_sph,reverb_sph,max_sample_value),
    max_ = max([abs(anechoic_sph(:)); abs(reverb_sph(:))]);
    scaling_factor = max_sample_value / max_;
    anechoic_sph = anechoic_sph * scaling_factor;
    reverb_sph   = reverb_sph * scaling_factor;
end

function [name] = get_filename(filepath),
    [~,name,ext] = fileparts(filepath);
    name = [name,ext];
end

function reverbsyn = synthesis_reverberation(rir, speech)
    reverbsyn = zeros(length(speech),size(rir,2));
    for n = 1:size(rir,2),
        lreverb = conv(speech,rir(:,n));
        reverbsyn(:,n) = lreverb(1:length(speech));
    end
end

function num = draw(range),
    if range(1) > range(2),
    error('error\n');
    end
    num = (range(2)-range(1))*rand+range(1);
end
