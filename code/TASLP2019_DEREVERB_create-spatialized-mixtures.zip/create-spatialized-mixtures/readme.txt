#Copyright [2020] [Zhong-Qiu Wang] (The Ohio State University)

#Licensed under the Apache License, Version 2.0 (the "License");
#you may not use this file except in compliance with the License.
#You may obtain a copy of the License at

#http://www.apache.org/licenses/LICENSE-2.0

#Unless required by applicable law or agreed to in writing, software
#distributed under the License is distributed on an "AS IS" BASIS,
#WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#See the License for the specific language governing permissions and
#limitations under the License.

This code is for the generation of reverberant data used in [1].

-generate_all_RIRs.m generates all the RIRs (NOTE slow even with parfor).
    You will need to change rir_dir and addpath your RIR-Generator.
-spatialize_WSJ0CAM.m uses the generated RIRs to simulate noisy-reverberant mixtures.
    Specify rir_dir, change REVERB_data_root to your REVERB dir, change data_root_wsj0cam to your WSJCAM0 dir, and data_root_to_save.

References
[1] Z.-Q. Wang and D.L. Wang, "Deep Learning Based Target Cancellation for Speech Dereverberation", in IEEE/ACM T-ASLP, vol. 28, pp. 941-950, Dec. 2020.
